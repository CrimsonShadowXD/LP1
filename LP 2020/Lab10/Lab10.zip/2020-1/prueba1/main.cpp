/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: crimson
 *
 * Created on July 16, 2020, 1:26 PM
 */

#include "Superclase.h"

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    Superclase p;
    p.CargarPilas();
    p.ImprimirColas();
    p.CargarSTL();
    p.ImprimirSTL();
    return 0;
}

