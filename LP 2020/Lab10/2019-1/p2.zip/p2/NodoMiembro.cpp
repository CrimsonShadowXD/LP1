/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   NodoMiembro.cpp
 * Author: crimson
 * 
 * Created on July 9, 2020, 8:24 PM
 */

#include "NodoMiembro.h"

NodoMiembro::NodoMiembro() {
    sig=NULL;
}

NodoMiembro::NodoMiembro(const NodoMiembro& orig) {
}

NodoMiembro::~NodoMiembro() {
}

