/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Producto.cpp
 * Author: crimson
 * 
 * Created on July 14, 2020, 1:11 PM
 */

#include "Producto.h"

Producto::Producto() {
}

Producto::Producto(const Producto& orig) {
}

Producto::~Producto() {
}

void Producto::SetCod(const char* cad) {
    if (cad == NULL) return;
    if (cod != NULL) delete cod;
    cod = new char[strlen(cad) + 1];
    strcpy(cod, cad);
}

void Producto::GetCod(char* cad) const {
    if (cod == NULL)
        return;
    strcpy(cad, cod);
}

void Producto::leer(ifstream&in){
    char cad[50];
    in.getline(cad,50);
    SetCod(cad);
}

void Producto::imprimir(ofstream&out){
    
}

void Producto::llenarP(ifstream&in){
    lpallet.crear(in);
}
