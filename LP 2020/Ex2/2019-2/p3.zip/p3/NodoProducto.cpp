/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   NodoProducto.cpp
 * Author: crimson
 * 
 * Created on July 14, 2020, 1:11 PM
 */

#include "NodoProducto.h"

NodoProducto::NodoProducto() {
    sig=NULL;
}

NodoProducto::NodoProducto(const NodoProducto& orig) {
}

NodoProducto::~NodoProducto() {
}

