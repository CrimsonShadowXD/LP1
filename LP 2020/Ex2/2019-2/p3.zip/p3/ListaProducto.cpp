/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   ListaProducto.cpp
 * Author: crimson
 * 
 * Created on July 14, 2020, 1:11 PM
 */

#include "ListaProducto.h"

ListaProducto::ListaProducto() {
    inicio=NULL;
}

ListaProducto::ListaProducto(const ListaProducto& orig) {
}

ListaProducto::~ListaProducto() {
}

void ListaProducto::crear(ifstream&in){
    NodoProducto *nuevo;
    while(1){
        nuevo=new NodoProducto;
        nuevo->elem.leer(in);
        if(in.eof())break;
        this->insertar(nuevo);        
    }
}

void ListaProducto::insertar(NodoProducto*nuevo){
    NodoProducto *p,*ant;
    ant=NULL;
    p=inicio;
    while(p){
//        if(p->elem > nuevo->elem)break;
        ant=p;
        p=p->sig;
    }
    nuevo->sig=p;
//    nuevo->ant=ant;
//    if(p)p->ant=nuevo;
    if(ant)ant->sig=nuevo;
    else inicio=nuevo;
}

void ListaProducto::imprime(ofstream&out){
    NodoProducto *p;
    p=inicio;
    while(p){
//        p->elem.imprimirP(out);
        p=p->sig;
        out<<endl;
    }
}

void ListaProducto::llenarPallet(ifstream&in){
    
    char cad[10],auxCad[10];
    in.getline(cad,10,',');
    NodoProducto *p;
    p=inicio;
    while(p){
        p->elem.GetCod(auxCad);
        cout<<cad<<endl;
        cout<<auxCad<<endl;
        cout<<strcmp(auxCad,cad)<<endl;
        if(strcmp(auxCad,cad)==0)break;
        p=p->sig;
    }
    exit(1);
}

