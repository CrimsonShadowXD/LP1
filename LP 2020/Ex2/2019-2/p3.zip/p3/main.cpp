/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: crimson
 *
 * Created on July 14, 2020, 1:00 PM
 */

#include "ListaProducto.h"

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    ListaProducto p;
    ifstream arch("producto.csv",ios::in);
    if(!arch){
        cerr<<"error"<<endl;
        exit(1);
    }
    ifstream in("stock.csv",ios::in);
    if(!in){
        cerr<<"error"<<endl;
        exit(1);
    }
    p.crear(arch);
    p.llenarPallet(in);
    
    return 0;
}

