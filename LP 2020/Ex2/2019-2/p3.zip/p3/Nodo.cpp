/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Nodo.cpp
 * Author: crimson
 * 
 * Created on July 9, 2020, 1:18 AM
 */

#include "Nodo.h"

Nodo::Nodo() {
    sig=NULL;
}

Nodo::Nodo(const Nodo& orig) {
}

Nodo::~Nodo() {
}

