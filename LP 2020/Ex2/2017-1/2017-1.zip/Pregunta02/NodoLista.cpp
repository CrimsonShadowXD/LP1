/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   NodoLista.cpp
 * Author: crimson
 * 
 * Created on July 19, 2020, 5:20 PM
 */

#include "NodoLista.h"

NodoLista::NodoLista() {
    elem=NULL;
    sig=NULL;
}

NodoLista::NodoLista(const NodoLista& orig) {
}

NodoLista::~NodoLista() {
}

