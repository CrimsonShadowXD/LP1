/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   ListaVehiculos.h
 * Author: crimson
 *
 * Created on July 20, 2020, 6:23 AM
 */

#ifndef LISTAVEHICULOS_H
#define LISTAVEHICULOS_H
#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
#include <vector>

using namespace std;

class ListaVehiculos {
private:

public:
    ListaVehiculos();
    ListaVehiculos(const ListaVehiculos& orig);
    virtual ~ListaVehiculos();

};

#endif /* LISTAVEHICULOS_H */

