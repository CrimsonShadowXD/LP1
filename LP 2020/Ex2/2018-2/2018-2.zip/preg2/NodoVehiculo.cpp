/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   NodoVehiculo.cpp
 * Author: crimson
 * 
 * Created on July 20, 2020, 6:37 AM
 */

#include "NodoVehiculo.h"

NodoVehiculo::NodoVehiculo() {
    sig=NULL;
    ant=NULL;
}

NodoVehiculo::NodoVehiculo(const NodoVehiculo& orig) {
}

NodoVehiculo::~NodoVehiculo() {
}

