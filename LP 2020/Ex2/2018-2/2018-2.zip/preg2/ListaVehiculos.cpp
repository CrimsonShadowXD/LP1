/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   ListaVehiculos.cpp
 * Author: crimson
 * 
 * Created on July 20, 2020, 6:23 AM
 */

#include "ListaVehiculos.h"

ListaVehiculos::ListaVehiculos() {
}

ListaVehiculos::ListaVehiculos(const ListaVehiculos& orig) {
}

ListaVehiculos::~ListaVehiculos() {
}

