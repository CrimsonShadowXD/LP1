/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   NodoArbol.cpp
 * Author: crimson
 * 
 * Created on July 19, 2020, 1:09 PM
 */

#include "NodoArbol.h"

NodoArbol::NodoArbol() {
    izq=NULL;
    der=NULL;
}

NodoArbol::NodoArbol(const NodoArbol& orig) {
}

NodoArbol::~NodoArbol() {
}

