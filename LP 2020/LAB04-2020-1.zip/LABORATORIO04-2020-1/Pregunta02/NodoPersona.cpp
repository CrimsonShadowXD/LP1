/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   NodoPersona.cpp
 * Author: Leandro Lazo La Rosa
 * Codigo: 20130263
 * Created on 10 de julio de 2020, 08:21 AM
 */

#include "NodoPersona.h"

NodoPersona::NodoPersona() {
    sig=NULL;
}

NodoPersona::NodoPersona(const NodoPersona& orig) {
}

NodoPersona::~NodoPersona() {
}

