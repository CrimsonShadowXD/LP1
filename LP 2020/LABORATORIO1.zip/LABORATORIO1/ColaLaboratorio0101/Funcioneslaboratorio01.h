/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Funcioneslaboratorio01.h
 * Author: Leandro Lazo La Rosa
 * Codigo: 20130263
 * Created on 19 de junio de 2020, 08:08 AM
 */

#ifndef FUNCIONESLABORATORIO01_H
#define FUNCIONESLABORATORIO01_H

#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>

using namespace std;

void imprimenumero(void *reg,ofstream& arch);
void *leenumero(ifstream& arch);


#endif /* FUNCIONESLABORATORIO01_H */

